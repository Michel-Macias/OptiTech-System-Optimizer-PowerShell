﻿# Variable global para la ruta del archivo de log.
$script:LogFilePath = ""

<#
.SYNOPSIS
    Inicializa el sistema de logging.
.DESCRIPTION
    Crea un directorio 'logs' en la misma ubicaciÃ³n que el script si no existe.
    Establece la ruta del archivo de log para la sesiÃ³n actual con el formato 'OptiTech_yyyy-MM-dd.log'.
#>
function Initialize-Logging {
    $logDir = "$script:g_OptiTechRoot/logs"
    if (-not (Test-Path -Path $logDir)) {
        New-Item -Path $logDir -ItemType Directory | Out-Null
    }
    $script:LogFilePath = "$logDir/OptiTech_$(Get-Date -Format 'yyyy-MM-dd').log"
}

